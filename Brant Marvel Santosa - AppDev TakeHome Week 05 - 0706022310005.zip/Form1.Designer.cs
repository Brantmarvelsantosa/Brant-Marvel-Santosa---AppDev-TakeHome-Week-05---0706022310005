﻿namespace Brant_Marvel_Santosa___AppDev_TakeHome_Week_05___0706022310005
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGV_Category = new System.Windows.Forms.DataGridView();
            this.DGV_ProdukTampil = new System.Windows.Forms.DataGridView();
            this.label_Product = new System.Windows.Forms.Label();
            this.label_Category = new System.Windows.Forms.Label();
            this.label_Details = new System.Windows.Forms.Label();
            this.label_namaproduct = new System.Windows.Forms.Label();
            this.label_productcategory = new System.Windows.Forms.Label();
            this.label_hargaproduct = new System.Windows.Forms.Label();
            this.label_stockproduct = new System.Windows.Forms.Label();
            this.TB_namaproduct = new System.Windows.Forms.TextBox();
            this.TB_harga = new System.Windows.Forms.TextBox();
            this.TB_stock = new System.Windows.Forms.TextBox();
            this.ComboBox_categoryproduct = new System.Windows.Forms.ComboBox();
            this.button_addproduct = new System.Windows.Forms.Button();
            this.TB_namacategory = new System.Windows.Forms.TextBox();
            this.label_namacategory = new System.Windows.Forms.Label();
            this.button_addcategory = new System.Windows.Forms.Button();
            this.button_all = new System.Windows.Forms.Button();
            this.button_filter = new System.Windows.Forms.Button();
            this.ComboBox_filter = new System.Windows.Forms.ComboBox();
            this.button_removeproduct = new System.Windows.Forms.Button();
            this.button_editproduct = new System.Windows.Forms.Button();
            this.button_removecategory = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_ProdukTampil)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_Category
            // 
            this.DGV_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Category.Location = new System.Drawing.Point(878, 65);
            this.DGV_Category.Name = "DGV_Category";
            this.DGV_Category.RowHeadersWidth = 62;
            this.DGV_Category.RowTemplate.Height = 28;
            this.DGV_Category.Size = new System.Drawing.Size(396, 330);
            this.DGV_Category.TabIndex = 0;
            this.DGV_Category.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // DGV_ProdukTampil
            // 
            this.DGV_ProdukTampil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_ProdukTampil.Location = new System.Drawing.Point(12, 62);
            this.DGV_ProdukTampil.Name = "DGV_ProdukTampil";
            this.DGV_ProdukTampil.RowHeadersWidth = 62;
            this.DGV_ProdukTampil.RowTemplate.Height = 28;
            this.DGV_ProdukTampil.Size = new System.Drawing.Size(846, 376);
            this.DGV_ProdukTampil.TabIndex = 1;
            this.DGV_ProdukTampil.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_ProdukTampil_CellContentClick);
            // 
            // label_Product
            // 
            this.label_Product.AutoSize = true;
            this.label_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Product.Location = new System.Drawing.Point(12, 14);
            this.label_Product.Name = "label_Product";
            this.label_Product.Size = new System.Drawing.Size(135, 37);
            this.label_Product.TabIndex = 2;
            this.label_Product.Text = "Product";
            // 
            // label_Category
            // 
            this.label_Category.AutoSize = true;
            this.label_Category.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Category.Location = new System.Drawing.Point(871, 14);
            this.label_Category.Name = "label_Category";
            this.label_Category.Size = new System.Drawing.Size(154, 37);
            this.label_Category.TabIndex = 3;
            this.label_Category.Text = "Category";
            // 
            // label_Details
            // 
            this.label_Details.AutoSize = true;
            this.label_Details.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Details.Location = new System.Drawing.Point(5, 452);
            this.label_Details.Name = "label_Details";
            this.label_Details.Size = new System.Drawing.Size(121, 37);
            this.label_Details.TabIndex = 4;
            this.label_Details.Text = "Details";
            // 
            // label_namaproduct
            // 
            this.label_namaproduct.AutoSize = true;
            this.label_namaproduct.Location = new System.Drawing.Point(15, 502);
            this.label_namaproduct.Name = "label_namaproduct";
            this.label_namaproduct.Size = new System.Drawing.Size(59, 20);
            this.label_namaproduct.TabIndex = 5;
            this.label_namaproduct.Text = "Nama :";
            // 
            // label_productcategory
            // 
            this.label_productcategory.AutoSize = true;
            this.label_productcategory.Location = new System.Drawing.Point(15, 542);
            this.label_productcategory.Name = "label_productcategory";
            this.label_productcategory.Size = new System.Drawing.Size(81, 20);
            this.label_productcategory.TabIndex = 6;
            this.label_productcategory.Text = "Category :";
            // 
            // label_hargaproduct
            // 
            this.label_hargaproduct.AutoSize = true;
            this.label_hargaproduct.Location = new System.Drawing.Point(15, 581);
            this.label_hargaproduct.Name = "label_hargaproduct";
            this.label_hargaproduct.Size = new System.Drawing.Size(61, 20);
            this.label_hargaproduct.TabIndex = 7;
            this.label_hargaproduct.Text = "Harga :";
            // 
            // label_stockproduct
            // 
            this.label_stockproduct.AutoSize = true;
            this.label_stockproduct.Location = new System.Drawing.Point(15, 620);
            this.label_stockproduct.Name = "label_stockproduct";
            this.label_stockproduct.Size = new System.Drawing.Size(58, 20);
            this.label_stockproduct.TabIndex = 8;
            this.label_stockproduct.Text = "Stock :";
            // 
            // TB_namaproduct
            // 
            this.TB_namaproduct.Location = new System.Drawing.Point(103, 499);
            this.TB_namaproduct.Name = "TB_namaproduct";
            this.TB_namaproduct.Size = new System.Drawing.Size(340, 26);
            this.TB_namaproduct.TabIndex = 9;
            this.TB_namaproduct.TextChanged += new System.EventHandler(this.TB_namaproduct_TextChanged);
            // 
            // TB_harga
            // 
            this.TB_harga.Location = new System.Drawing.Point(103, 578);
            this.TB_harga.Name = "TB_harga";
            this.TB_harga.Size = new System.Drawing.Size(193, 26);
            this.TB_harga.TabIndex = 10;
            // 
            // TB_stock
            // 
            this.TB_stock.Location = new System.Drawing.Point(103, 618);
            this.TB_stock.Name = "TB_stock";
            this.TB_stock.Size = new System.Drawing.Size(193, 26);
            this.TB_stock.TabIndex = 11;
            // 
            // ComboBox_categoryproduct
            // 
            this.ComboBox_categoryproduct.FormattingEnabled = true;
            this.ComboBox_categoryproduct.Location = new System.Drawing.Point(103, 538);
            this.ComboBox_categoryproduct.Name = "ComboBox_categoryproduct";
            this.ComboBox_categoryproduct.Size = new System.Drawing.Size(193, 28);
            this.ComboBox_categoryproduct.TabIndex = 12;
            this.ComboBox_categoryproduct.SelectedIndexChanged += new System.EventHandler(this.ComboBox_categoryproduct_SelectedIndexChanged);
            // 
            // button_addproduct
            // 
            this.button_addproduct.BackColor = System.Drawing.Color.Lime;
            this.button_addproduct.Location = new System.Drawing.Point(341, 558);
            this.button_addproduct.Name = "button_addproduct";
            this.button_addproduct.Size = new System.Drawing.Size(82, 66);
            this.button_addproduct.TabIndex = 13;
            this.button_addproduct.Text = "Add Product";
            this.button_addproduct.UseVisualStyleBackColor = false;
            this.button_addproduct.Click += new System.EventHandler(this.button_addproduct_Click);
            // 
            // TB_namacategory
            // 
            this.TB_namacategory.Location = new System.Drawing.Point(955, 417);
            this.TB_namacategory.Name = "TB_namacategory";
            this.TB_namacategory.Size = new System.Drawing.Size(319, 26);
            this.TB_namacategory.TabIndex = 15;
            // 
            // label_namacategory
            // 
            this.label_namacategory.AutoSize = true;
            this.label_namacategory.Location = new System.Drawing.Point(874, 418);
            this.label_namacategory.Name = "label_namacategory";
            this.label_namacategory.Size = new System.Drawing.Size(59, 20);
            this.label_namacategory.TabIndex = 14;
            this.label_namacategory.Text = "Nama :";
            // 
            // button_addcategory
            // 
            this.button_addcategory.BackColor = System.Drawing.Color.Lime;
            this.button_addcategory.Location = new System.Drawing.Point(900, 479);
            this.button_addcategory.Name = "button_addcategory";
            this.button_addcategory.Size = new System.Drawing.Size(86, 66);
            this.button_addcategory.TabIndex = 16;
            this.button_addcategory.Text = "Add Category";
            this.button_addcategory.UseVisualStyleBackColor = false;
            this.button_addcategory.Click += new System.EventHandler(this.button_addcategory_Click);
            // 
            // button_all
            // 
            this.button_all.Location = new System.Drawing.Point(489, 21);
            this.button_all.Name = "button_all";
            this.button_all.Size = new System.Drawing.Size(75, 30);
            this.button_all.TabIndex = 17;
            this.button_all.Text = "All";
            this.button_all.UseVisualStyleBackColor = true;
            this.button_all.Click += new System.EventHandler(this.button_all_Click);
            // 
            // button_filter
            // 
            this.button_filter.Location = new System.Drawing.Point(577, 20);
            this.button_filter.Name = "button_filter";
            this.button_filter.Size = new System.Drawing.Size(75, 30);
            this.button_filter.TabIndex = 18;
            this.button_filter.Text = "Filter :";
            this.button_filter.UseVisualStyleBackColor = true;
            this.button_filter.Click += new System.EventHandler(this.button_filter_Click);
            // 
            // ComboBox_filter
            // 
            this.ComboBox_filter.FormattingEnabled = true;
            this.ComboBox_filter.Location = new System.Drawing.Point(665, 21);
            this.ComboBox_filter.Name = "ComboBox_filter";
            this.ComboBox_filter.Size = new System.Drawing.Size(193, 28);
            this.ComboBox_filter.TabIndex = 19;
            this.ComboBox_filter.SelectedIndexChanged += new System.EventHandler(this.ComboBox_filter_SelectedIndexChanged);
            // 
            // button_removeproduct
            // 
            this.button_removeproduct.BackColor = System.Drawing.Color.Red;
            this.button_removeproduct.Location = new System.Drawing.Point(517, 558);
            this.button_removeproduct.Name = "button_removeproduct";
            this.button_removeproduct.Size = new System.Drawing.Size(82, 66);
            this.button_removeproduct.TabIndex = 20;
            this.button_removeproduct.Text = "Remove Product";
            this.button_removeproduct.UseVisualStyleBackColor = false;
            this.button_removeproduct.Click += new System.EventHandler(this.button_removeproduct_Click);
            // 
            // button_editproduct
            // 
            this.button_editproduct.BackColor = System.Drawing.Color.Yellow;
            this.button_editproduct.Location = new System.Drawing.Point(429, 558);
            this.button_editproduct.Name = "button_editproduct";
            this.button_editproduct.Size = new System.Drawing.Size(82, 66);
            this.button_editproduct.TabIndex = 21;
            this.button_editproduct.Text = "Edit Product";
            this.button_editproduct.UseVisualStyleBackColor = false;
            this.button_editproduct.Click += new System.EventHandler(this.button_editproduct_Click);
            // 
            // button_removecategory
            // 
            this.button_removecategory.BackColor = System.Drawing.Color.Red;
            this.button_removecategory.Location = new System.Drawing.Point(992, 479);
            this.button_removecategory.Name = "button_removecategory";
            this.button_removecategory.Size = new System.Drawing.Size(91, 66);
            this.button_removecategory.TabIndex = 22;
            this.button_removecategory.Text = "Remove Category";
            this.button_removecategory.UseVisualStyleBackColor = false;
            this.button_removecategory.Click += new System.EventHandler(this.button_removecategory_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(1357, 654);
            this.Controls.Add(this.button_removecategory);
            this.Controls.Add(this.button_editproduct);
            this.Controls.Add(this.button_removeproduct);
            this.Controls.Add(this.ComboBox_filter);
            this.Controls.Add(this.button_filter);
            this.Controls.Add(this.button_all);
            this.Controls.Add(this.button_addcategory);
            this.Controls.Add(this.TB_namacategory);
            this.Controls.Add(this.label_namacategory);
            this.Controls.Add(this.button_addproduct);
            this.Controls.Add(this.ComboBox_categoryproduct);
            this.Controls.Add(this.TB_stock);
            this.Controls.Add(this.TB_harga);
            this.Controls.Add(this.TB_namaproduct);
            this.Controls.Add(this.label_stockproduct);
            this.Controls.Add(this.label_hargaproduct);
            this.Controls.Add(this.label_productcategory);
            this.Controls.Add(this.label_namaproduct);
            this.Controls.Add(this.label_Details);
            this.Controls.Add(this.label_Category);
            this.Controls.Add(this.label_Product);
            this.Controls.Add(this.DGV_ProdukTampil);
            this.Controls.Add(this.DGV_Category);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_ProdukTampil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_Category;
        private System.Windows.Forms.DataGridView DGV_ProdukTampil;
        private System.Windows.Forms.Label label_Product;
        private System.Windows.Forms.Label label_Category;
        private System.Windows.Forms.Label label_Details;
        private System.Windows.Forms.Label label_namaproduct;
        private System.Windows.Forms.Label label_productcategory;
        private System.Windows.Forms.Label label_hargaproduct;
        private System.Windows.Forms.Label label_stockproduct;
        private System.Windows.Forms.TextBox TB_namaproduct;
        private System.Windows.Forms.TextBox TB_harga;
        private System.Windows.Forms.TextBox TB_stock;
        private System.Windows.Forms.ComboBox ComboBox_categoryproduct;
        private System.Windows.Forms.Button button_addproduct;
        private System.Windows.Forms.TextBox TB_namacategory;
        private System.Windows.Forms.Label label_namacategory;
        private System.Windows.Forms.Button button_addcategory;
        private System.Windows.Forms.Button button_all;
        private System.Windows.Forms.Button button_filter;
        private System.Windows.Forms.ComboBox ComboBox_filter;
        private System.Windows.Forms.Button button_removeproduct;
        private System.Windows.Forms.Button button_editproduct;
        private System.Windows.Forms.Button button_removecategory;
    }
}

