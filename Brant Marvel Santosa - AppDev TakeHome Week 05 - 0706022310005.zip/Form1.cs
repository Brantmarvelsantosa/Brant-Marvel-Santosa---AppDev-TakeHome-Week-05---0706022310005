﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Brant_Marvel_Santosa___AppDev_TakeHome_Week_05___0706022310005
{
    public partial class Form1 : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();
        string idproduk = "";
        int idcategory = -1;
        bool delete = false;
        bool delete2 = false;
        public Form1()
        {
            InitializeComponent();
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");

            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            dtProdukSimpan.Rows.Add("J001", "Jas Putih", "1000000", "5", "C2");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Adidas", "70000", "20", "C1");
            dtProdukSimpan.Rows.Add("R001", "Rok Panjang", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans slim Fit", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Olahraga", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("R001", "Uniqlo Shirt", "50000", "8", "C1");

            dtCategory.Rows.Add("C1", "T-Shirt");
            dtCategory.Rows.Add("C2", "Jas");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            


            DGV_ProdukTampil.AllowUserToAddRows = false;
            DGV_Category.AllowUserToAddRows = false;

            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                string id = dtProdukSimpan.Rows[i][0].ToString();
                string nama = dtProdukSimpan.Rows[i][1].ToString();
                string category = dtProdukSimpan.Rows[i][4].ToString();
                string harga = dtProdukSimpan.Rows[i][2].ToString();
                string stok = dtProdukSimpan.Rows[i][3].ToString();

                dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
            }

            DGV_ProdukTampil.DataSource = dtProdukTampil;
            DGV_Category.DataSource = dtCategory;

            ComboBox_categoryproduct.Items.Clear();
            ComboBox_filter.Items.Clear();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                ComboBox_categoryproduct.Items.Add(dtCategory.Rows[i][1].ToString());
                ComboBox_filter.Items.Add(dtCategory.Rows[i][1].ToString());
            }

            DGV_ProdukTampil.AllowUserToAddRows = false;
            DGV_Category.AllowUserToAddRows = false;

            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                string id = dtProdukSimpan.Rows[i][0].ToString();
                string nama = dtProdukSimpan.Rows[i][1].ToString();
                string category = dtProdukSimpan.Rows[i][4].ToString();
                string harga = dtProdukSimpan.Rows[i][2].ToString();
                string stok = dtProdukSimpan.Rows[i][3].ToString();

                dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
            }

            DGV_ProdukTampil.DataSource = dtProdukTampil;
            DGV_Category.DataSource = dtCategory;

            ComboBox_categoryproduct.Items.Clear();
            ComboBox_filter.Items.Clear();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                ComboBox_categoryproduct.Items.Add(dtCategory.Rows[i][1].ToString());
                ComboBox_filter.Items.Add(dtCategory.Rows[i][1].ToString());
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            DGV_ProdukTampil.ClearSelection();
            DGV_Category.ClearSelection();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = DGV_Category.CurrentCell.RowIndex;
            TB_namacategory.Text = dtCategory.Rows[index][1].ToString();
            delete2 = true;
        }

        private void button_addproduct_Click(object sender, EventArgs e)
        {
            if (TB_namaproduct.Text != "" && TB_harga.Text != "" && TB_stock.Text != "" && idcategory != -1)
            {
                string hurufpertama = TB_namaproduct.Text.Substring(0, 1).ToUpper();
                int idcount = 0;
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString().Contains(hurufpertama + "00"))
                    {
                        idcount = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(3, 1));
                    }
                    else if (dtProdukSimpan.Rows[i][0].ToString().Contains(hurufpertama + "0"))
                    {
                        idcount = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(2, 2));
                    }
                    else if (dtProdukSimpan.Rows[i][0].ToString().Substring(0, 1) == hurufpertama)
                    {
                        idcount = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(1, 3));
                    }

                }
                string tid = "";
                idcount = idcount + 1;

                if (idcount < 10)
                {
                    tid = hurufpertama + "00" + idcount.ToString();
                }
                else if (idcount < 100)
                {
                    tid = hurufpertama + "0" + idcount.ToString();
                }
                else
                {
                    tid = hurufpertama + idcount.ToString();
                }
                string tnama = TB_namaproduct.Text;
                string tcategory = dtCategory.Rows[idcategory][0].ToString();
                string tharga = TB_harga.Text;
                string tstok = TB_stock.Text;

                dtProdukSimpan.Rows.Add(tid, tnama, tharga, tstok, tcategory);

                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }
                TB_namaproduct.Text = "";
                TB_harga.Text = "";
                TB_stock.Text = "";
                ComboBox_categoryproduct.SelectedIndex = -1;
                idcategory = -1;
            }
            else
            {
                MessageBox.Show("Requirement Unfufilled");
            }
        }

        private void button_addcategory_Click(object sender, EventArgs e)
        {
            if (TB_namacategory.Text != "")
            {
                bool adacategori = true;
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (TB_namacategory.Text == dtCategory.Rows[i][1].ToString())
                    {
                        adacategori = false;
                        break;
                    }
                }
                if (adacategori)
                {
                    int idbaru = 0;
                    if (dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Length == 2)
                    {
                        idbaru = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1, 1));
                    }
                    else if (dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Length == 3)
                    {
                        idbaru = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1, 2));
                    }
                    else
                    {
                        idbaru = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1, 3));
                    }
                    idbaru = idbaru + 1;
                    string idbarustr = "C" + idbaru.ToString();

                    dtCategory.Rows.Add(idbarustr, TB_namacategory.Text);
                }
                else
                {
                    MessageBox.Show("Category already inputed");
                }

                ComboBox_categoryproduct.Items.Clear();
                ComboBox_filter.Items.Clear();
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    ComboBox_categoryproduct.Items.Add(dtCategory.Rows[i][1].ToString());
                    ComboBox_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                }

                ComboBox_categoryproduct.SelectedIndex = -1;
                ComboBox_filter.SelectedIndex = -1;

                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }

                TB_namaproduct.Text = "";
                TB_harga.Text = "";
                TB_stock.Text = "";
                idcategory = -1;
            }
            else
            {
                MessageBox.Show("Please input a name");
            }

        }

        private void DGV_ProdukTampil_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = DGV_ProdukTampil.CurrentCell.RowIndex;
            delete = true;

            idproduk = dtProdukTampil.Rows[index][0].ToString();
            string nama = dtProdukTampil.Rows[index][1].ToString();
            string category = dtProdukTampil.Rows[index][4].ToString();
            string harga = dtProdukTampil.Rows[index][2].ToString();
            string stok = dtProdukTampil.Rows[index][3].ToString();

            TB_namaproduct.Text = nama;
            TB_harga.Text = harga;
            TB_stock.Text = stok;

            idcategory = -1;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][0].ToString() == category)
                {
                    ComboBox_categoryproduct.SelectedIndex = i;
                    idcategory = i;
                    break;
                }
            }
        }

        private void ComboBox_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtProdukTampil.Clear();

            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtCategory.Rows[ComboBox_filter.SelectedIndex][0].ToString() == dtProdukSimpan.Rows[i][4].ToString())
                {
                    string id = dtProdukSimpan.Rows[i][0].ToString();
                    string nama = dtProdukSimpan.Rows[i][1].ToString();
                    string category = dtProdukSimpan.Rows[i][4].ToString();
                    string harga = dtProdukSimpan.Rows[i][2].ToString();
                    string stok = dtProdukSimpan.Rows[i][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }
            }
        }

        private void button_all_Click(object sender, EventArgs e)
        {
            ComboBox_filter.Enabled = false;
            ComboBox_filter.SelectedIndex = -1;

            dtProdukTampil.Clear();
            for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
            {
                string id = dtProdukSimpan.Rows[j][0].ToString();
                string nama = dtProdukSimpan.Rows[j][1].ToString();
                string category = dtProdukSimpan.Rows[j][4].ToString();
                string harga = dtProdukSimpan.Rows[j][2].ToString();
                string stok = dtProdukSimpan.Rows[j][3].ToString();

                dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
            }
        }

        private void button_filter_Click(object sender, EventArgs e)
        {
            ComboBox_filter.Enabled = true;
        }

        private void TB_namaproduct_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_editproduct_Click(object sender, EventArgs e)
        {
            if (TB_namaproduct.Text != "" && TB_harga.Text != "" && TB_stock.Text != "" && idcategory != -1)
            {
                int index = DGV_ProdukTampil.CurrentCell.RowIndex;

                string idbarang = dtProdukTampil.Rows[index][0].ToString();
                string tnama = TB_namaproduct.Text;
                string tcategory = dtCategory.Rows[idcategory][0].ToString();
                string tharga = TB_harga.Text;
                string tstok = TB_stock.Text;

                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString() == idbarang)
                    {
                        dtProdukSimpan.Rows[i][1] = tnama;
                        dtProdukSimpan.Rows[i][4] = tcategory;
                        dtProdukSimpan.Rows[i][2] = tharga;
                        dtProdukSimpan.Rows[i][3] = tstok;
                        break;
                    }
                }

                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }


                TB_namaproduct.Text = "";
                TB_harga.Text = "";
                TB_stock.Text = "";
                ComboBox_categoryproduct.SelectedIndex = -1;
                idcategory = -1;
            }
            else
            {
                MessageBox.Show("Requirement Unfufilled");
            }


        }

        private void ComboBox_categoryproduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            idcategory = ComboBox_categoryproduct.SelectedIndex;
        }

        private void button_removeproduct_Click(object sender, EventArgs e)
        {
            if (TB_namaproduct.Text != "" && TB_harga.Text != "" && TB_stock.Text != "" && idcategory != -1 && delete)
            {
                int index = DGV_ProdukTampil.CurrentCell.RowIndex;

                string idbarang = dtProdukTampil.Rows[index][0].ToString();

                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString() == idbarang)
                    {
                        dtProdukSimpan.Rows[i].Delete();
                        break;
                    }
                }

                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }


                TB_namaproduct.Text = "";
                TB_harga.Text = "";
                TB_stock.Text = "";
                ComboBox_categoryproduct.SelectedIndex = -1;
                idcategory = -1;
                delete = false;
            }
            else
            {
                MessageBox.Show("Please Select a row");
            }

        }

        private void button_removecategory_Click(object sender, EventArgs e)
        {
            if (TB_namacategory.Text != "" && delete2)
            {
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    if (dtProdukSimpan.Rows[j][4].ToString() == dtCategory.Rows[DGV_Category.CurrentCell.RowIndex][0].ToString())
                    {
                        dtProdukSimpan.Rows[j].Delete();
                        j = 0;
                    }
                }


                dtCategory.Rows[DGV_Category.CurrentCell.RowIndex].Delete();

                ComboBox_categoryproduct.SelectedIndex = -1;
                ComboBox_filter.SelectedIndex = -1;
                dtProdukTampil.Clear();
                for (int j = 0; j < dtProdukSimpan.Rows.Count; j++)
                {
                    string id = dtProdukSimpan.Rows[j][0].ToString();
                    string nama = dtProdukSimpan.Rows[j][1].ToString();
                    string category = dtProdukSimpan.Rows[j][4].ToString();
                    string harga = dtProdukSimpan.Rows[j][2].ToString();
                    string stok = dtProdukSimpan.Rows[j][3].ToString();

                    dtProdukTampil.Rows.Add(id, nama, harga, stok, category);
                }

                ComboBox_categoryproduct.Items.Clear();
                ComboBox_filter.Items.Clear();
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    ComboBox_categoryproduct.Items.Add(dtCategory.Rows[i][1].ToString());
                    ComboBox_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                }

                TB_namaproduct.Text = "";
                TB_namacategory.Text = "";
                TB_harga.Text = "";
                TB_stock.Text = "";
                delete2 = false;
                idcategory = -1;
            }
            else
            {
                MessageBox.Show("Please select a row");
            }

        }
    }
}
